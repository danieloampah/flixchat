package com.mycompany.flixchat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
